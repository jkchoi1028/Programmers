package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.DeptDTO;
import com.service.DeptServiceImpl;


@WebServlet("/DeptSelectServlet")
public class DeptSelectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//Service 연동
		DeptServiceImpl service = new DeptServiceImpl();
		List<DeptDTO> list = service.select();
		
		//1) JSP에서 보여줄 데이터 저장 (scope)
		request.setAttribute("list", list);
		
		//2) JSP 위임 (redirect, forward )
		//request에 지금 했으므로 forward만 됨!
		RequestDispatcher dis = request.getRequestDispatcher("list.jsp");
		dis.forward(request, response);
		
//		//응답처리 //원래는 jsp로 위임해야하는데 이 경우에는 바로 응답.
//		response.setContentType("text/html;charset=utf-8");
//		PrintWriter out = response.getWriter();
//		out.print("<html><body>");
//		for (DeptDTO dto : list) {
//			out.print(dto + "<br>");
//		}
//		out.print("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8"); // 사용자가 입력한 한글데이터
		doGet(request, response);
	}

}
