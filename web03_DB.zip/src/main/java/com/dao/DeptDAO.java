package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dto.DeptDTO;

//DAO: Data Access Object
//DB 전담 클래스. 일반적으로 테이블 당 한개씩 작성함.
public class DeptDAO {

	// sql + preparedStatement + ResultSet

	public List<DeptDTO> select(Connection con) {
		List<DeptDTO> list = new ArrayList<>();
	
		//4. SQL문 작성 ==> 반드시 SQL문 마지막에 ; 제거 필수
		String sql = "select deptno as no, dname as name, loc from dept";
		//5.preparedStatement ==> SQL문 전송
		PreparedStatement pstmt = null;
		ResultSet rs = null; //close 해줘야하기때문에
		try {
			pstmt = con.prepareStatement(sql);
			//6. sql문 전송
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int deptno = rs.getInt("no");
				String dname = rs.getString("name");
				String loc = rs.getString(3);
				DeptDTO dto = new DeptDTO(deptno, dname, loc);
				list.add(dto);
			}	
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return list;
}
}
